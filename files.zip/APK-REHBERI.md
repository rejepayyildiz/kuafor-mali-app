# APK Olusturma Rehberi - Telefondan Adim Adim

## Gerekli Dosyalar (5 tane)

```
index.html      ← Ana uygulama
manifest.json   ← PWA ayarlari
sw.js           ← Offline calisma
icon-192.png    ← Kucuk ikon
icon-512.png    ← Buyuk ikon
```

---

## ADIM 1: GitHub'a Yukle (5 dakika)

1. github.com ac, giris yap
2. Sag ustte "+" tikla → "New repository"
3. Repository adi: `kuafor-mali-app`
4. Public sec
5. "Create repository" tikla
6. "Upload files" tikla
7. 5 dosyayi surukle (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
8. "Commit changes" tikla

---

## ADIM 2: GitHub Pages Ac (3 dakika)

1. Repository sayfasinda "Settings" sekmesine git
2. Sol menude "Pages" tikla
3. Source kisminda "Deploy from a branch" sec
4. Branch: "main" sec, klasor: "/ (root)" sec
5. "Save" tikla
6. 1-2 dakika bekle
7. Sayfanin ustunde yesil link gorunecek:
   `https://KULLANICIADIN.github.io/kuafor-mali-app`

Bu linki telefonunun tarayicisinda ac, uygulamayi goreceksin!

---

## ADIM 3: APK Olustur (10 dakika)

### YONTEM 1: PWABuilder (En Kolay - Tavsiye)

1. Telefonun tarayicisinda ac: **pwabuilder.com**
2. Kutuya GitHub Pages linkini yapistir:
   `https://KULLANICIADIN.github.io/kuafor-mali-app`
3. "Start" tikla
4. Analiz bitmesini bekle (30 saniye)
5. "Package For Stores" tikla
6. "Android" sec
7. "Generate" tikla
8. APK dosyasi indirilecek
9. Telefonuna yukle ve kur!

### YONTEM 2: ApkCreator (Telefondan)

1. Google Play Store'dan indir: **"Website to APK Builder"** veya **"ApkCreator"**
2. Uygulamayi ac
3. URL kismina GitHub Pages linkini yaz
4. Uygulama adi: "Kuafor Mali"
5. Ikon sec (icon-512.png)
6. "Build APK" tikla
7. APK olusturulacak
8. "Install" tikla

### YONTEM 3: AkerSoft AppMaker (Telefondan)

1. Play Store'dan indir: **"AppMaker - Web to App"**
2. URL: GitHub Pages linkin
3. Ad: Kuafor Mali Yonetim
4. Ikon: icon-512.png
5. Fullscreen: Evet
6. Build tikla

---

## ADIM 4: APK'yi Kur

### Telefonunda:
1. Ayarlar → Guvenlik → "Bilinmeyen Kaynaklar" ac
   (veya "Bu kaynaktan uygulamalara izin ver")
2. Indirilen APK dosyasina tikla
3. "Yukle" tikla
4. Uygulama ana ekranina eklenir

---

## ALTERNATIF: APK Olmadan Telefona Ekle (PWA)

GitHub Pages linkini actiktan sonra:

### Android Chrome:
1. Chrome'da linki ac
2. Sag ustte 3 nokta menusune tikla
3. "Ana ekrana ekle" sec
4. "Ekle" tikla
5. Uygulama ikonu ana ekraninda gorunur
6. Tam ekran acilir, tarayici gibi degil!

### iPhone Safari:
1. Safari'de linki ac
2. Altta paylasim ikonuna tikla (kare + ok)
3. "Ana Ekrana Ekle" sec
4. "Ekle" tikla
5. Uygulama ikonu ana ekraninda gorunur

Bu yontemle APK'ya bile gerek yok!

---

## OZET

En kolay yol:
```
1. 5 dosyayi GitHub'a yukle
2. GitHub Pages ac
3. Telefonda Chrome'dan ac
4. "Ana ekrana ekle"
5. BITTI - Uygulama hazir!
```

APK istiyorsan:
```
1. 5 dosyayi GitHub'a yukle
2. GitHub Pages ac
3. pwabuilder.com'dan APK olustur
4. Telefonuna yukle
5. BITTI!
```
